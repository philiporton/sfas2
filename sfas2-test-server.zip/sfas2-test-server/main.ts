import express from "express";
import cors from "cors";
import routesConfig from "./routes/index.ts";

const app = express();
const PORT = 4000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
routesConfig(app);

app.listen(PORT, () => {
    console.log(`Server running @ http://localhost:${PORT}`);
    console.log(`Test resources @ http://localhost:${PORT}/cgi-bin/get_sfas_stations.py`);
});
