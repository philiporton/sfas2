import type { Express } from "express";
import binRoutes from "./cgi-bin.ts";

const constructorMethod = (app: Express) => {
    app.use("/cgi-bin", binRoutes);
    
    app.use("*", (req, res) => {
        res.status(404).send("Not found");
    });
};

export default constructorMethod;
