import { exec } from "child_process";
import { Router } from "express";

const router = Router();

router.route("/get_sfas_stations.py").get((req, res) => {
    console.log("GET /cgi-bin/get_sfas_stations.py");
    exec("python bin/get_sfas_stations.py", (error, stdout, stderr) => {
        if (error) {
            return res.status(500).set("Content-Type", "text/html").send(stderr);
        } else {
            return res.status(200).send(stdout.replace(/content-type: text\/html/gi, ""));
        }
    });
});

export default router;
